package DBCXN;
import java.sql.*;
/**
 *
 * @author kyleharris
 */
public class DBConnection {

    private Connection conn; // database connection instance variable

    final String PUBLIC_DNS = "triton.towson.edu";
    final String PORT = "3360";
    final String DATABASE = "rwilli3db";
    final String DBUSER = "rwilli3";
    final String DBPASS = "Cosc*d6h7";
    
    private boolean cxn_status = false;


    public void connectToDatabase() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Where is your MySQL JDBC Driver?");
            e.printStackTrace();
        }

        System.out.println("MySQL JDBC Driver Registered!");
        Connection connection = null;

        try {
            connection = DriverManager.
                    getConnection("jdbc:mysql://" + PUBLIC_DNS + ":" + PORT + "/" + DATABASE, DBUSER, DBPASS);
        } catch (SQLException e) {
            System.out.println("Connection Failed!:\n" + e.getMessage());
        }

        if (connection != null) {
            System.out.println("Connection Status: SUCCESS");
            this.setConnection(true);
        
        } else {
            System.out.println("Connection Status: FAILED.");
            this.setConnection(false);
        }
        // set the instance variable to the value of the new connecton
        this.conn = connection;
    }
    
    
    public boolean getConnectionStatus(){
        return this.cxn_status;
    }
    
    public void setConnection(boolean status){
        this.cxn_status = status;
    }

    /** The following function returns a ResultSet object after the
     * SQL query has been run.
     */

    private ResultSet queryResult(String query) throws Exception{
        Statement stmt = this.conn.createStatement();
        return stmt.executeQuery(query);
    }
    
    private int updateResult(String query) throws Exception{
        Statement st = this.conn.createStatement();
        return st.executeUpdate(query);
    }

    /* The two functions work in conjunction - the private function doesn't contain any error handling, mainly
        because it doesn't need to. The public function will handle it if it arises.
     */

    public ResultSet executeQuery(String query){

        ResultSet rs;
        try{
            rs = this.queryResult(query); // in some cases, this can't handle an update
        }catch(Exception e){
            //
            rs = null; // well rs isn't going to be anything if it's a bad query so init as null
            System.out.println(e.getMessage());
   
        }
        return rs;
    }

    
    public int executeUpdate(String query){
        int status;
        try{
            status = this.updateResult(query);
        }catch(Exception e){
            status = 1;
            System.out.println(e.getMessage());
        }
        
        return status;
    }
}