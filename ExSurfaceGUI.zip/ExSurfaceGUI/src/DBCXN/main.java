package DBCXN; 

import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.*;

/**
 * Created by Kyle Harris on 9/5/17.
 */
public class main {
    
    public static boolean connected = false;
    public static void connect(){
        // function just tests the database connectivity
        DBConnection dbc = new DBConnection();
        dbc.connectToDatabase();
        
        Statement st = null;
        
        if(dbc.getConnectionStatus()){
            connected = true;
        }
        // the DBConnection class only handles the connection and the queries. It doesn't parse the result sets
        String query = "SELECT * FROM employee;";
        
        
        
        ResultReader reader = new ResultReader(dbc.executeQuery(query));
        System.out.println(reader.toString());
        
      
        // code snippet will iterate the arraylist
        ArrayList<String> columns = reader.getColumns();
        // now get the data in the database..
        for(String col : columns){
            System.out.println(col);
        }
        
        System.out.println("FUGGG ME");
        
        ArrayList<ArrayList<String>> rows = reader.getRows();
        //System.out.println((rows.toString()));
        for(ArrayList row : rows){
            // get the current row
           System.out.println("Printing rows");
            for(int i = 0; i<row.size(); i++){
                System.out.print(row.get(i) + " ");
            }
            System.out.println("\n");
        }
               
    
    }
}
